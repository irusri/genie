define(
"dojox/editor/plugins/nls/sk/Blockquote", ({
	"blockquote": "Blok citátu"
})
);
