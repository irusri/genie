define(
"dojox/editor/plugins/nls/it/Save", ({
	"save": "Salva"
})
);
