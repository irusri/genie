define(
"dojox/editor/plugins/nls/it/AutoSave", ({
	"saveLabel": "Salva",
	"saveSettingLabelOn": "Imposta intervallo di salvataggio automatico...",
	"saveSettingLabelOff": "Disattiva salvataggio automatico",
	"saveSettingdialogTitle": "Salvataggio automatico",
	"saveSettingdialogDescription": "Specifica intervallo di salvataggio automatico",
	"saveSettingdialogParamName": "Intervallo di salvataggio automatico",
	"saveSettingdialogParamLabel": "min",
	"saveSettingdialogButtonOk": "Imposta intervallo",
	"saveSettingdialogButtonCancel": "Annulla",
	"saveMessageSuccess": "Salvato alle ${0}",
	"saveMessageFail": "Salvataggio alle ${0} non riuscito"
})
);
