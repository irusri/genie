define(
"dojox/editor/plugins/nls/sk/Save", ({
	"save": "Uložiť"
})
);
