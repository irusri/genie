define(
"dojox/editor/plugins/nls/nl/Breadcrumb", ({
	"nodeActions": "${nodeName} Acties",
	"selectContents": "Inhoud selecteren",
	"selectElement": "Element selecteren",
	"deleteElement": "Element wissen",
	"deleteContents": "Inhoud wissen",
	"moveStart": "Cursor verplaatsen naar start",
	"moveEnd": "Cursor verplaatsen naar eind"
})
);
