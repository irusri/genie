define(
"dojox/editor/plugins/nls/ca/CollapsibleToolbar", ({
	"collapse": "Redueix la barra d'eines de l'editor",
	"expand": "Expandeix la barra d'eines de l'editor"
})
);
