define(
"dojox/editor/plugins/nls/el/PageBreak", ({
	"pageBreak": "Αλλαγή σελίδας"
})
);
