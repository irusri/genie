define(
"dojox/editor/plugins/nls/it/ShowBlockNodes", ({
	"showBlockNodes": "Mostra elementi blocco HTML"
})
);
