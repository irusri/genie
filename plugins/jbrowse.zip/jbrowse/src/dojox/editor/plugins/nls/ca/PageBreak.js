define(
"dojox/editor/plugins/nls/ca/PageBreak", ({
	"pageBreak": "Salt de pàgina"
})
);
