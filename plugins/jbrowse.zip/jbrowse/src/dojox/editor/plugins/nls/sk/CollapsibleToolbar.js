define(
"dojox/editor/plugins/nls/sk/CollapsibleToolbar", ({
	"collapse": "Zvinúť lištu nástrojov editora",
	"expand": "Rozvinúť lištu nástrojov editora"
})
);
