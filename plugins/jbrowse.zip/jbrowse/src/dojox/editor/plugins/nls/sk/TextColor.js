define(
"dojox/editor/plugins/nls/sk/TextColor", ({
	"setButtonText": "Nastaviť",
	"cancelButtonText": "Zrušiť"
})
);
