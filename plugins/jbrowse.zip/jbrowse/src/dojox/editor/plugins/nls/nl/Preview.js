define(
"dojox/editor/plugins/nls/nl/Preview", ({
	"preview": "Preview"
})
);
