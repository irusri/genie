define(
"dojox/editor/plugins/nls/sk/InsertEntity", ({
	insertEntity: "Vložiť symbol"
})
);
