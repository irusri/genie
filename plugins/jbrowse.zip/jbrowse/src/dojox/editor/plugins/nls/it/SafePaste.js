define(
"dojox/editor/plugins/nls/it/SafePaste", ({
	"instructions": "Non è possibile incollare direttamente. Incollare i contenuti in questa finestra di dialogo utilizzando i controlli standard da menu o da tastiera del browser. Quando si è deciso quali contenuti inserire, fare clic sul pulsante incolla. Per interrompere l'inserimento dei contenuti premere il pulsante annulla."
})
);
