define(
"dojox/editor/plugins/nls/nl/Blockquote", ({
	"blockquote": "Blockquote"
})
);
