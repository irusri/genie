define(
"dojox/editor/plugins/nls/sk/Preview", ({
	"preview": "Náhľad"
})
);
