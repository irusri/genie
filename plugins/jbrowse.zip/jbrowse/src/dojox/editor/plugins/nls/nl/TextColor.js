define(
"dojox/editor/plugins/nls/nl/TextColor", ({
	"setButtonText": "Instellen",
	"cancelButtonText": "Annuleren"
})
);
