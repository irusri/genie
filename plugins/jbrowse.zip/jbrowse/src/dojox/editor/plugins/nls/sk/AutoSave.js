define(
"dojox/editor/plugins/nls/sk/AutoSave", ({
	"saveLabel": "Uložiť",
	"saveSettingLabelOn": "Nastaviť interval automatického ukladania...",
	"saveSettingLabelOff": "Vypnúť automatické ukladanie",
	"saveSettingdialogTitle": "Automatické ukladanie",
	"saveSettingdialogDescription": "Zadajte interval automatického ukladania",
	"saveSettingdialogParamName": "Interval automatického ukladania",
	"saveSettingdialogParamLabel": "min",
	"saveSettingdialogButtonOk": "Nastaviť interval",
	"saveSettingdialogButtonCancel": "Zrušiť",
	"saveMessageSuccess": "Uložené o ${0}",
	"saveMessageFail": "Zlyhalo ukladanie o ${0}"
})
);
