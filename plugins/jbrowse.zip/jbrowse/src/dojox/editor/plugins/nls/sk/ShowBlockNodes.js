define(
"dojox/editor/plugins/nls/sk/ShowBlockNodes", ({
	"showBlockNodes": "Zobraziť elementy blokov HTML"
})
);
