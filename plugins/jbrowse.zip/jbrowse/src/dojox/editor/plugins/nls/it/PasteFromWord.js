define(
"dojox/editor/plugins/nls/it/PasteFromWord", ({
	"pasteFromWord": "Incolla da Word",
	"instructions": "Incollare i contenuti da Word nella seguente casella di testo. Quando si è deciso quali contenuti inserire, fare clic sul pulsante incolla. Per interrompere l'inserimento del testo premere il pulsante annulla."
})
);
