define(
"dojox/editor/plugins/nls/nl/Save", ({
	"save": "Opslaan"
})
);
