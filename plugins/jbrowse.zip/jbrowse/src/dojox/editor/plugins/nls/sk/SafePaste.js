define(
"dojox/editor/plugins/nls/sk/SafePaste", ({
	"instructions": "Priame prilepenie je zakázané.  Prilepte obsah do tohto dialógového okna s použitím štandardných klávesnicových alebo ponukových ovládacích prvkov prehliadača.  Keď budete spokojný s vloženým obsahom, stlačte tlačidlo Prilepiť.  Ak chcete zrušiť vkladanie obsahu, kliknite na tlačidlo Zrušiť."
})
);
