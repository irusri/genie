define(
"dojox/editor/plugins/nls/sk/PageBreak", ({
	"pageBreak": "Zlom strany"
})
);
