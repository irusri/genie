define(
"dojox/editor/plugins/nls/nl/ShowBlockNodes", ({
	"showBlockNodes": "HTML-blokelementen afbeelden"
})
);
