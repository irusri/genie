define(
"dojox/editor/plugins/nls/nl/AutoSave", ({
	"saveLabel": "Opslaan",
	"saveSettingLabelOn": "Interval voor automatisch opslaan instellen...",
	"saveSettingLabelOff": "Automatisch opslaan uitschakelen",
	"saveSettingdialogTitle": "Automatisch opslaan",
	"saveSettingdialogDescription": "Geef het interval voor Automatisch opslaan op.",
	"saveSettingdialogParamName": "Interval voor Automatisch opslaan",
	"saveSettingdialogParamLabel": "min",
	"saveSettingdialogButtonOk": "Interval instellen",
	"saveSettingdialogButtonCancel": "Annuleren",
	"saveMessageSuccess": "Opgeslagen om ${0}",
	"saveMessageFail": "Opslaan mislukt om ${0}"
})
);
