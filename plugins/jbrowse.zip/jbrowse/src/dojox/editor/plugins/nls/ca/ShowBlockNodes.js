define(
"dojox/editor/plugins/nls/ca/ShowBlockNodes", ({
	"showBlockNodes": "Mostra elements de bloc HTML"
})
);
