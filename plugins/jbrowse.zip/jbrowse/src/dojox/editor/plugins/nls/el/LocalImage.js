define(
"dojox/editor/plugins/nls/el/LocalImage", ({
	insertImageTitle: "Εισαγωγή εικόνας",
	url: "Εικόνα",
	browse: "Αναζήτηση...",
	text: "Περιγραφή",
	set: "Εισαγωγή",
	invalidMessage: "Μη έγκυρο είδος αρχείου εικόνας",
	prePopuTextUrl: "Καταχωρήστε τη διεύθυνση URL μιας εικόνας",
	prePopuTextBrowse: " ή επιλέξτε ένα τοπικό αρχείο."
})
);
