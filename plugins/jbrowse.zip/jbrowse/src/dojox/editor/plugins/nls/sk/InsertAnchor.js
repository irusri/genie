define(
"dojox/editor/plugins/nls/sk/InsertAnchor", ({
	insertAnchor: "Vložiť kotvu",
	title: "Vlastnosti kotvy",
	anchor: "Názov:",
	text: "Opis:",
	set: "Nastaviť",
	cancel: "Zrušiť"
})
);
