define(
"dojox/editor/plugins/nls/it/Breadcrumb", ({
	"nodeActions": "Azioni ${nodeName}",
	"selectContents": "Seleziona contenuti",
	"selectElement": "Seleziona elemento",
	"deleteElement": "Elimina elemento",
	"deleteContents": "Elimina contenuti",
	"moveStart": "Sposta cursore all'inizio",
	"moveEnd": "Sposta cursore alla fine"
})
);
