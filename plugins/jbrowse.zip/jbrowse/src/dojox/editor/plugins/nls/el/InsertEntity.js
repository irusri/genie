define(
"dojox/editor/plugins/nls/el/InsertEntity", ({
	insertEntity: "Εισαγωγή συμβόλου"
})
);
