define(
"dojox/editor/plugins/nls/nl/PageBreak", ({
	"pageBreak": "Paginaeinde"
})
);
