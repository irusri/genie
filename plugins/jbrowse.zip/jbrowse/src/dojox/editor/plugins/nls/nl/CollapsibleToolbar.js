define(
"dojox/editor/plugins/nls/nl/CollapsibleToolbar", ({
	"collapse": "Editor-werkbalk samenvouwen",
	"expand": "Editor-werkbalk uitvouwen"
})
);
