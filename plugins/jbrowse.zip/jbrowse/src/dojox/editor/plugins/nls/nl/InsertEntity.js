define(
"dojox/editor/plugins/nls/nl/InsertEntity", ({
	insertEntity: "Symbool invoegen"
})
);
