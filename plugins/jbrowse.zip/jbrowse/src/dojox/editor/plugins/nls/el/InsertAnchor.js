define(
"dojox/editor/plugins/nls/el/InsertAnchor", ({
	insertAnchor: "Εισαγωγή αγκίστρωσης",
	title: "Ιδιότητες αγκίστρωσης",
	anchor: "Όνομα:",
	text: "Περιγραφή:",
	set: "Ορισμός",
	cancel: "Ακύρωση"
})
);
