define(
"dojox/editor/plugins/nls/nl/InsertAnchor", ({
	insertAnchor: "Anker invoegen",
	title: "Ankereigenschappen",
	anchor: "Naam:",
	text: "Beschrijving:",
	set: "Instellen",
	cancel: "Annuleren"
})
);
