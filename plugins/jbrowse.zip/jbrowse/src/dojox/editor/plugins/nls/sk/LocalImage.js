define(
"dojox/editor/plugins/nls/sk/LocalImage", ({
	insertImageTitle: "Vložiť obrázok",
	url: "Obrázok",
	browse: "Prehľadať...",
	text: "Opis",
	set: "Vložiť",
	invalidMessage: "Neplatný typ súboru obrázka",
	prePopuTextUrl: "Zadajte adresu URL",
	prePopuTextBrowse: "alebo nájdite lokálny súbor."
})
);
