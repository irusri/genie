define(
"dojox/editor/plugins/nls/it/PageBreak", ({
	"pageBreak": "Interruzione pagina"
})
);
